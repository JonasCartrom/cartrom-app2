# 🔥 GUIA DE CONFIGURAÇÃO — FIREBASE + CARTROM APP

## PASSO 1 — Criar projeto no Firebase

1. Acesse: https://console.firebase.google.com
2. Clique em **"Adicionar projeto"**
3. Nome do projeto: `cartrom-app`
4. Desative o Google Analytics (opcional) → Clique **"Criar projeto"**

---

## PASSO 2 — Ativar Authentication (Login)

1. No menu lateral, clique em **Authentication** → **Começar**
2. Clique na aba **"Sign-in method"**
3. Clique em **"E-mail/senha"** → Ative → Salvar

---

## PASSO 3 — Criar usuários

1. Ainda em **Authentication** → aba **"Usuários"**
2. Clique **"Adicionar usuário"** para cada pessoa:
   - E-mail: `lider1@cartrom.com.br` / Senha: (defina)
   - E-mail: `tecnico1@cartrom.com.br` / Senha: (defina)
   - (repita para todos os usuários)
3. **Anote o UID** de cada usuário (aparece na lista)

---

## PASSO 4 — Criar banco de dados Firestore

1. No menu lateral, clique em **Firestore Database** → **Criar banco de dados**
2. Escolha **"Iniciar no modo de produção"** → Próximo
3. Escolha a região: `southamerica-east1 (São Paulo)` → Ativar

### Configurar regras de segurança:
Clique na aba **"Regras"** e substitua pelo conteúdo abaixo:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Usuários: cada um lê o próprio perfil
    match /usuarios/{uid} {
      allow read: if request.auth.uid == uid;
      allow write: if false; // só admin cria usuários
    }

    // Projetos
    match /projetos/{projetoId} {
      // Técnico: lê/cria/edita apenas os seus
      allow read, update, delete: if request.auth != null &&
        (resource.data.autorId == request.auth.uid ||
         get(/databases/$(database)/documents/usuarios/$(request.auth.uid)).data.papel == 'lideranca');
      allow create: if request.auth != null;
    }
  }
}
```

Clique **"Publicar"**.

---

## PASSO 5 — Criar coleção de usuários (papéis)

1. Ainda no Firestore, clique em **"Iniciar coleção"**
2. Nome da coleção: `usuarios`
3. Para cada usuário, crie um documento:
   - **ID do documento**: cole o UID do usuário (copiado no Passo 3)
   - Campos:
     ```
     nome:  "Nome da Pessoa"       (string)
     papel: "lideranca"            (string) ← para líderes
     papel: "tecnico"              (string) ← para técnicos
     email: "email@cartrom.com.br" (string)
     ```

---

## PASSO 6 — Ativar Storage (para fotos e PDFs)

1. No menu lateral, clique em **Storage** → **Começar**
2. Escolha **"Iniciar no modo de produção"** → Próximo
3. Região: `southamerica-east1` → Concluído

### Regras do Storage:
Clique na aba **"Regras"** e substitua por:

```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if request.auth != null;
    }
  }
}
```

Clique **"Publicar"**.

---

## PASSO 7 — Obter credenciais do Firebase

1. Clique na engrenagem ⚙️ → **"Configurações do projeto"**
2. Role até **"Seus aplicativos"** → clique no ícone **`</>`** (Web)
3. Nome do app: `cartrom-web` → Registrar app
4. Copie o objeto `firebaseConfig` que aparecer

---

## PASSO 8 — Colar credenciais no código

Abra o arquivo `src/firebase.js` e substitua os valores:

```js
const firebaseConfig = {
  apiKey: "AIzaSy...",           // ← cole o seu
  authDomain: "cartrom-app.firebaseapp.com",
  projectId: "cartrom-app",
  storageBucket: "cartrom-app.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abc..."
};
```

---

## PASSO 9 — Publicar na Vercel

1. Suba a pasta `cartrom-app` para o GitHub
2. Importe no Vercel:
   - Framework: **Vite**
   - Build Command: `npm run build`
   - Output Directory: `dist`
3. Clique **Deploy** ✅

---

## RESUMO DOS PAPÉIS

| Papel       | O que pode fazer                                      |
|-------------|-------------------------------------------------------|
| `tecnico`   | Ver/criar/editar/excluir **seus** projetos            |
| `lideranca` | Ver **todos** os projetos, editar, excluir, aprovar/reprovar ficha |

---

## ❓ Dúvidas?
Entre em contato com o suporte técnico.
